﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace wpfblingblim
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            var rnd = new Random();
            var imie = imie.Text;
            var nazwisko = nazwisko.Text;
            var pesel = pesel.Text;




           // listView.Items.Add(new { m_nID = rnd.Next(), m_strName=imie, m_strSname=nazwisko, m_strPESEL=pesel });
        }
    }
}